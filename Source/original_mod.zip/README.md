# Star Wars - Factions
Expands the rimverse with many iconic and memorable weapons, apparel, and factions from Star Wars lore.



Xen's Public notes:

1. Requirements:
**This mod requires JecsTools to run properly.**
https://github.com/jecrell/JecsTools

2. Powers Notes:
Powers should all be functioning properly.
Lvl 1 powers are not "Alignment locked"  -so a gray jedi can use most force powers

3. Saber notes:
There should be minimal issues with the Sabers. 

Currently crafted at Component Assembly Bench
Sabers need a crystal to function
Crystals affect saber color and attack speed/damage - also other potential benefits (deflection etc)
Basic crystals can be refined from stony at electric smelter, rarer crystals come from traders (currently)
pawns wielding a saber must be drafted to activate saber (so be careful not to let them get jumped unawares)
pawns will auto-deactivate sabers upon cancelling draft

4. Factions notes
The "factions" mod is basically a dump for my overproductivity in generating weapons and armor and other content.

Imperial and Rebel factions -
Imperial taxes now implemented 
more guns and armor added

Most weapons and armor from this are craftable with basic "Complex clothing", "Powered armor", and "Charged Shot" researches.
